WayForPay - SimplaCMS
==============

Модуль оплаты WayForPay для SimplaCMS 2.x

<?php
require_once('View.php');

echo 'на печать $br_out_discont';
		echo $br_out_discont;
		
